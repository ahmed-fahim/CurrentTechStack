//
//  main.m
//  iOS_Audio
//
//  Created by Fahim Ahmed on 10/17/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
