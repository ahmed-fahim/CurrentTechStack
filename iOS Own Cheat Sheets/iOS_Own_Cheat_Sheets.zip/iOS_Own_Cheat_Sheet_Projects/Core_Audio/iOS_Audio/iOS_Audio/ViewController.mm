//
//  ViewController.m
//  iOS_Audio
//
//  Created by Fahim Ahmed on 11/5/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#import "ViewController.h"
#include "AuController.h"

@interface ViewController ()

@end

@implementation ViewController
{
	AuController *iOS_AudioController;
    BOOL pttFlag;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    pttFlag = 1;
    if(pttFlag){
        iOS_AudioController = new AuController(MCPTT);
    }
    else{
        iOS_AudioController = new AuController(REALTIME);
    }
    iOS_AudioController->AUDIOFW_SET_WAVEINFORMAT();
    iOS_AudioController->AUDIOFW_SET_WAVEOUTFORMAT();
    
    iOS_AudioController->AUDIOFW_WAVEINOPEN();
    iOS_AudioController->AUDIOFW_WAVEOUTOPEN();
    // Do any additional setup after loading the view from its nib.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)RESET_AUDIO_UNIT:(id)sender {
	if(iOS_AudioController->getOutputUnit() != nil){
		iOS_AudioController->AUDIOFW_WAVEINHANDLE_CLEAR();
		iOS_AudioController->AUDIOFW_WAVEOUTHANDLE_CHECK();
	}
    if(pttFlag){
        iOS_AudioController = new AuController(MCPTT);
    }
    else{
        iOS_AudioController = new AuController(REALTIME);
    }

	iOS_AudioController->AUDIOFW_SET_WAVEINFORMAT();
	iOS_AudioController->AUDIOFW_SET_WAVEOUTFORMAT();

	iOS_AudioController->AUDIOFW_WAVEINOPEN();
	iOS_AudioController->AUDIOFW_WAVEOUTOPEN();
}
- (IBAction)WAVE_IN_START:(id)sender {
	iOS_AudioController->AUDIOFW_WAVEINSTART();
    if(!pttFlag){
        iOS_AudioController->AUDIOFW_WAVEOUTSTART();
    }
}

- (IBAction)WAVE_IN_CLOSE:(id)sender {
	iOS_AudioController->AUDIOFW_WAVEINCLOSE();
    if(pttFlag){
        iOS_AudioController->AUDIOFW_WAVEOUTSTART();
    }
    else{
        iOS_AudioController->AUDIOFW_WAVEOUTCLOSE();
    }
}
@end
