//
//  ChannelListViewController.swift
//  SwiftDemoUI
//
//  Created by Fahim Ahmed on 2/13/19.
//  Copyright © 2019 com.samsung.srbd.push.test. All rights reserved.
//

import UIKit
import Foundation

class ChannelListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
	/**
	*	UI Instances
	**/
	@IBOutlet weak var ChannelListTable: UITableView!

	/**
	*	Member Constants
	**/
	let IDLE_ChannelSectionHeader = "IDLE"
	let ACTIVE_ChannelSectionHeader = "ACTIVE"
	let channelListRowHeight:CGFloat = 50;

	/**
	*	Member Instance Variables
	**/
	var channelListDictionary: NSMutableDictionary;


    override func viewDidLoad() {
		super.viewDidLoad();


		ChannelListTable?.delegate = self;
		ChannelListTable?.dataSource = self;
		//ChannelListTable!.reloadData()
        // Do any additional setup after loading the view.
    }
	override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
		channelListDictionary = NSMutableDictionary.init();

		super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil);
		self.dummyDataFeel()
	}
	required init?(coder aDecoder: NSCoder) {
		channelListDictionary = NSMutableDictionary.init();
		super.init(coder: aDecoder);
	}
	func numberOfSections(in tableView: UITableView) -> Int {
		var retVal:Int = channelListDictionary.allKeys.count;
		return retVal;
	}
	func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
		return self.channelListRowHeight;
	}
	func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		//TODO:
	}

	func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
		let keys:NSArray = channelListDictionary.allKeys as NSArray;
		let retVal:String? = (keys.object(at: section) as! String);
		return retVal;
	}

	func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		let val = section;
		let keys:NSArray = channelListDictionary.allKeys as NSArray
		let channelListForKey:NSMutableArray = channelListDictionary.object(forKey: keys.object(at: section)) as! NSMutableArray;
		return channelListForKey.count;
	}

	func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		var currentCell: UITableViewCell? = ChannelListTable.dequeueReusableCell(withIdentifier: "cell");
		if(currentCell == nil){
			currentCell = UITableViewCell.init(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "cell");
		}
		let sectionHeader:String? = (channelListDictionary.allKeys[indexPath.section] as! String);
		print(sectionHeader!)
		currentCell?.textLabel?.text = (channelListDictionary.object(forKey: sectionHeader!) as! NSMutableArray).object(at: indexPath.row) as? String;
		return currentCell!
	}

	func addChannel(channelName:String, channelType:String){
		var channelListForChannelType: NSMutableArray? = self.channelListDictionary.object(forKey: channelType) as? NSMutableArray;
		if(channelListForChannelType != nil){
			channelListForChannelType!.add(channelName);
		}
		else{
			channelListForChannelType = NSMutableArray.init(object: channelName);
		}
		channelListDictionary.setObject(channelListForChannelType! , forKey: channelType as NSCopying);
	}
	func dummyDataFeel(){
		for index in stride(from: 0, to: 10, by: +1){
			var dummyChannelName: String;
			var channelType:String;

			if(index % 2 == 0){
				dummyChannelName = "IDLE Channel No: \(Int(index/2))";
				channelType = IDLE_ChannelSectionHeader;
			}
			else{
				dummyChannelName = "ACTIVE Channel No: \(Int(index/2))";
				channelType = ACTIVE_ChannelSectionHeader;
			}

			self.addChannel(channelName: dummyChannelName, channelType: channelType);
		}

		for (key,valueArray) in channelListDictionary{
			print("Key \(key) = {");
			for instance in (valueArray as! NSMutableArray){
				print("\(instance) ")
			}
			print("}\n");
		}

		print("Fin");
	}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
