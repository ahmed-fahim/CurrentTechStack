//
//  main.m
//  cppObjectStore
//
//  Created by Fahim Ahmed on 2/18/19.
//  Copyright © 2019 com.samsung.srbd.push.test. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <Foundation/Foundation.h>
#include <iostream>
#include <fstream>
#include <cassert>
#include <cstdlib>
#include <cstdint>

using namespace std;

struct SSL_Sample_struct{
	int a, b;
	SSL_Sample_struct(int aArg, int bArg){
		a=aArg;
		b=bArg;
	}
};



int main(int argc, char * argv[]) {
	SSL_Sample_struct d(2,3);
	
	cout<<"Before Storing "<<d.a<<" "<<d.b<<endl;
	int sizeOfData = sizeof(d);

	//Storing the size of the object in binary format in keyChain
	[[NSUserDefaults standardUserDefaults] setObject:[NSNumber numberWithInt:sizeOfData] forKey:@"sizeOfData"];

	//storing the object in binary format in an unsigend char* array
	unsigned char *readable = new unsigned char[sizeOfData];
	readable = reinterpret_cast<unsigned char*>(&d);

	//storing this binary object in keyChain in NSData format
	NSData *SSLData = [NSData dataWithBytes:readable length:sizeOfData];
	[[NSUserDefaults standardUserDefaults] setObject:SSLData forKey:@"SSLData"];

	//restoring the binary object from keyChain in NSData format
	NSData *restoredSSLData = [[NSUserDefaults standardUserDefaults] objectForKey:@"SSLData"];

	//restoring the binary object in unsigned char* format
	unsigned char *restoredValue = new unsigned char[[[NSUserDefaults standardUserDefaults] integerForKey:@"sizeOfData"] ];
	restoredValue = (unsigned char*)([restoredSSLData bytes]);

	//converting unsigned char* back to Object type
	SSL_Sample_struct *dd = reinterpret_cast<SSL_Sample_struct*> (restoredValue);
	cout<<"After reading " << dd->a<<" "<<dd->b<<endl;



}
