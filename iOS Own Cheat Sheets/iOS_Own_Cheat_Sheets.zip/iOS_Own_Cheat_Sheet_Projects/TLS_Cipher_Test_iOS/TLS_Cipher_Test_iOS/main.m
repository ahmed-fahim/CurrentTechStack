//
//  main.m
//  TLS_Cipher_Test_iOS
//
//  Created by Fahim Ahmed on 7/2/19.
//  Copyright © 2019 com.samsung.srbd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
