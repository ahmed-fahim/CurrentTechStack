//
//  ViewController.swift
//  PortChecker
//
//  Created by Fahim Ahmed on 3/13/19.
//  Copyright © 2019 com.samsung.srbd.push.test. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		
		// Do any additional setup after loading the view, typically from a nib.
	}

	func checkTcpPortForListen(port: in_port_t){

		let socketFileDescriptor = socket(AF_INET, SOCK_STREAM, 0)
		if socketFileDescriptor == -1 {
			print("Port :: \(port) Closed")
		}

		var addr = sockaddr_in()
		let sizeOfSockkAddr = MemoryLayout<sockaddr_in>.size
		addr.sin_len = __uint8_t(sizeOfSockkAddr)
		addr.sin_family = sa_family_t(AF_INET)
		addr.sin_port = Int(OSHostByteOrder()) == OSLittleEndian ? _OSSwapInt16(port) : port
		addr.sin_addr = in_addr(s_addr: inet_addr("0.0.0.0"))
		addr.sin_zero = (0, 0, 0, 0, 0, 0, 0, 0)
		var bind_addr = sockaddr()
		memcpy(&bind_addr, &addr, Int(sizeOfSockkAddr))

		if Darwin.bind(socketFileDescriptor, &bind_addr, socklen_t(sizeOfSockkAddr)) == -1 {
			let details = descriptionOfLastError()
			release(socket: socketFileDescriptor)
			print("Port :: \(port) Closed")
		}
		if listen(socketFileDescriptor, SOMAXCONN ) == -1 {
			let details = descriptionOfLastError()
			release(socket: socketFileDescriptor)
			print("Port :: \(port) Closed")
		}
		release(socket: socketFileDescriptor)
		print("Port :: \(port) Open")
	}

	func release(socket: Int32) {
		Darwin.shutdown(socket, SHUT_RDWR)
		close(socket)
	}

	func descriptionOfLastError() -> String {
		return String.init(cString: (UnsafePointer(strerror(errno))))
	}


}

