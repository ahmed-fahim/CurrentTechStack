//
//  ViewController.h
//  iOS_Audio
//
//  Created by Fahim Ahmed on 11/5/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewController : UIViewController
- (IBAction)RESET_AUDIO_UNIT:(id)sender;
- (IBAction)WAVE_IN_START:(id)sender;
- (IBAction)WAVE_IN_CLOSE:(id)sender;
@end

NS_ASSUME_NONNULL_END
