//
//  AuController.m
//  iOS_Audio
//
//  Created by Fahim Ahmed on 10/17/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//



#import "AuController.h"
#include <algorithm>
#include <iostream>

#define kOutputBus 0
#define kInputBus 1
OSStatus status;
unsigned int iterationCount;

static OSStatus recordingCallback(void *inRefCon,
								  AudioUnitRenderActionFlags *ioActionFlags,
								  const AudioTimeStamp *inTimeStamp,
								  UInt32 inBusNumber,
								  UInt32 inNumberFrames,
								  AudioBufferList *ioData);

static OSStatus playbackCallback(void *inRefCon,
								 AudioUnitRenderActionFlags *ioActionFlags,
								 const AudioTimeStamp *inTimeStamp,
								 UInt32 inBusNumber,
								 UInt32 inNumberFrames,
								 AudioBufferList *ioData);
void checkStatus(OSStatus var){
	if(var != 0){
		printf("#DEBUG Previous execution Had error\n");
	}
	else{
		printf("#DEBUG Previous execution was successful\n");
	}
}

AuController::AuController(){
	//default constructor
	this->MODE = MCPTT;
    bufferQueue = [[NSMutableArray alloc] init];
	this->AUDIOFW_SET_WAVEDESCRIPTION();
}
AuController::AuController(AuMode MODE_PARAMS){
	printf("#DEBUG AuController::AuController()\n");
	//overloaded constructor
    bufferQueue = [[NSMutableArray alloc] init];
	this->MODE = MODE_PARAMS;
	this->AUDIOFW_SET_WAVEDESCRIPTION();
}
void AuController::AUDIOFW_SET_WAVEDESCRIPTION(){
	printf("#DEBUG AuController::AUDIOFW_SET_WAVEDESCRIPTION()\n");
	//preparing the audio description
	audioDesc.componentType = kAudioUnitType_Output;
	audioDesc.componentSubType = kAudioUnitSubType_RemoteIO;
	audioDesc.componentFlags = 0;
	audioDesc.componentFlagsMask = 0;
	audioDesc.componentManufacturer = kAudioUnitManufacturer_Apple;

	//Specifying the audio format details
	audioFormat.mSampleRate			= 44100.00;
	audioFormat.mFormatID			= kAudioFormatLinearPCM;
	audioFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
	audioFormat.mFramesPerPacket	= 1;
	audioFormat.mChannelsPerFrame	= 1;
	audioFormat.mBitsPerChannel		= 16;
	audioFormat.mBytesPerPacket		= 2;
	audioFormat.mBytesPerFrame		= 2;
}
void AuController::AUDIOFW_SET_WAVEINFORMAT(){
	printf("#DEBUG AuController::AUDIOFW_SET_WAVEINFORMAT()\n");
	//initializing the input audio component
	inputComponent = AudioComponentFindNext(NULL, &audioDesc);

	//instantiating an input audioUnit using the component
	status = AudioComponentInstanceNew(inputComponent, &inputUnit);
	checkStatus(status);

	unsigned int FLAG = 1;

	//instantiate audio input/recording in seperate audio unit
	status = AudioUnitSetProperty(inputUnit,
								  kAudioOutputUnitProperty_EnableIO,
								  kAudioUnitScope_Input,
								  kInputBus,
								  &FLAG,
								  sizeof(FLAG));
	checkStatus(status);

	//setting property for input audio Unit according to format details
	status = AudioUnitSetProperty(inputUnit,
								  kAudioUnitProperty_StreamFormat,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &audioFormat,
								  sizeof(audioFormat));
	checkStatus(status);

	//setting input Call Back with required Reference and procedure
	inputCallBack.inputProcRefCon = this;
	inputCallBack.inputProc = recordingCallback;
	status = AudioUnitSetProperty(inputUnit,
								  kAudioOutputUnitProperty_SetInputCallback,
								  kAudioUnitScope_Global,
								  kInputBus,
								  &inputCallBack,
								  sizeof(inputCallBack));
	checkStatus(status);

	//Setting mode to manually allocated buffer
	//instead of telling system to allocate buffer
	unsigned int ShouldAllocateBuffer = 0;
	status = AudioUnitSetProperty(inputUnit,
								  kAudioUnitProperty_ShouldAllocateBuffer,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &ShouldAllocateBuffer,
								  sizeof(ShouldAllocateBuffer));
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINOPEN(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINOPEN()\n");
	status = AudioUnitInitialize(inputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINSTART(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINSTART()\n");
	status = AudioOutputUnitStart(this->inputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEREAD(){

}
void AuController::AUDIOFW_WAVEINCLOSE(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINCLOSE()\n");
	status = AudioOutputUnitStop(this->inputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINHANDLE_CLEAR(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINHANDLE_CLEAR()\n");
	AudioComponentInstanceDispose(inputUnit);
}
void AuController::AUDIOFW_SET_WAVEOUTFORMAT(){
	printf("#DEBUG AuController::AUDIOFW_SET_WAVEOUTFORMAT()\n");
	//initializing the output audio component
	outputComponent = AudioComponentFindNext(NULL, &audioDesc);

	//instantiating an output audioUnit using the component
	status = AudioComponentInstanceNew(outputComponent, &outputUnit);
	checkStatus(status);


	unsigned int FLAG = 1;

	//instantiate audio output/playback in seperate audio unit
	status = AudioUnitSetProperty(outputUnit,
								  kAudioOutputUnitProperty_EnableIO,
								  kAudioUnitScope_Output,
								  kOutputBus,
								  &FLAG,
								  sizeof(FLAG));
	checkStatus(status);


	//setting property for output audio Unit according to format details
	status = AudioUnitSetProperty(outputUnit,
								  kAudioUnitProperty_StreamFormat,
								  kAudioUnitScope_Input,
								  kOutputBus,
								  &audioFormat,
								  sizeof(audioFormat));
	checkStatus(status);


	//setting output Call Back with required Reference and procedure
	outputCallBack.inputProcRefCon = this;
	outputCallBack.inputProc = playbackCallback;
	status = AudioUnitSetProperty(outputUnit,
								  kAudioUnitProperty_SetRenderCallback,
								  kAudioUnitScope_Global,
								  kOutputBus,
								  &outputCallBack,
								  sizeof(outputCallBack));
	checkStatus(status);


	//Setting mode to manually allocated buffer
	//instead of telling system to allocate buffer
	unsigned int ShouldAllocateBuffer = 0;
	status = AudioUnitSetProperty(outputUnit,
								  kAudioUnitProperty_ShouldAllocateBuffer,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &ShouldAllocateBuffer,
								  sizeof(ShouldAllocateBuffer));
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEOUTOPEN(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTOPEN()\n");
	status = AudioUnitInitialize(outputUnit);
	checkStatus(status);
}
void AuController::AUDIOFW_WAVEOUTSTART(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTSTART()\n");
    this->bufferIndex=0;
	status = AudioOutputUnitStart(this->outputUnit);
	checkStatus(status);
}
void AuController::AUDIOFW_WAVEOUTCLOSE(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTCLOSE()\n");
	status = AudioOutputUnitStop(this->outputUnit);
	checkStatus(status);
}
void AuController::AUDIOFW_WAVEOUTHANDLE_CHECK(){
	status = AudioComponentInstanceDispose(this->outputUnit);
	checkStatus(status);
}
AudioUnit AuController::getInputUnit(){
	return this->inputUnit;
}
AudioUnit AuController::getOutputUnit(){
	return this->outputUnit;
}
NSMutableData* AuController::getAudioBuffer(unsigned int index){
    if(index >= [this->bufferQueue count]){
        exit(10);
    }
    return this->bufferQueue[index];
}
NSMutableData* AuController::getNextAudioBuffer(){
    unsigned int index = this->bufferIndex;
    if(index >= [this->bufferQueue count]){
        exit(10);
    }
    this->bufferIndex++;
    return this->bufferQueue[index];
}
bool AuController::bufferFinish(){
    return (this->bufferIndex >= [this->bufferQueue count]) ? true:false;
}
void AuController::AUDIOFW_ProcessAudio(AudioBufferList &bufferList){
	printf("#DEBUG AuController::AUDIOFW_ProcessAudio()\n");
	AudioBuffer sourceBuffer = bufferList.mBuffers[0];
    Float32 *frame = (Float32*)sourceBuffer.mData;
    NSMutableData *frameData = [[NSMutableData alloc] init];
    [frameData appendBytes:frame length:sourceBuffer.mDataByteSize];
    [this->bufferQueue addObject:frameData];
}

static OSStatus recordingCallback(void *inRefCon,
								  AudioUnitRenderActionFlags *ioActionFlags,
								  const AudioTimeStamp *inTimeStamp,
								  UInt32 inBusNumber,
								  UInt32 inNumberFrames,
								  AudioBufferList *ioData) {
	AudioBuffer buffer;
	buffer.mNumberChannels = 1;
	buffer.mDataByteSize = inNumberFrames * 2;
	buffer.mData = malloc(inNumberFrames * 2);

	AudioBufferList bufferList;
	bufferList.mNumberBuffers = 1;
	bufferList.mBuffers[0] = buffer;

	AuController &controllerInstance = *(AuController*)inRefCon;

	status = AudioUnitRender(controllerInstance.getInputUnit(),
							 ioActionFlags,
							 inTimeStamp,
							 inBusNumber,
							 inNumberFrames,
							 &bufferList);
	checkStatus(status);


	controllerInstance.AUDIOFW_ProcessAudio(bufferList);
	free(bufferList.mBuffers[0].mData);

	return noErr;
}
static OSStatus playbackCallback(void *inRefCon,
								 AudioUnitRenderActionFlags *ioActionFlags,
								 const AudioTimeStamp *inTimeStamp,
								 UInt32 inBusNumber,
								 UInt32 inNumberFrames,
								 AudioBufferList *ioData) {
	AuController &controllerInstance = *(AuController*)inRefCon;
	if(controllerInstance.bufferFinish() == true){
		controllerInstance.AUDIOFW_WAVEOUTCLOSE();
	}
	AudioBuffer buffer = ioData->mBuffers[0];
    NSMutableData *frameData = controllerInstance.getNextAudioBuffer();
    const void *_Nullable rawFrame = [frameData bytes];
    unsigned long FrameSize = [frameData length];
	unsigned long size = std::min((unsigned long)buffer.mDataByteSize, FrameSize);
	memcpy(buffer.mData, rawFrame, size);
	buffer.mDataByteSize = (unsigned int)size;
	return noErr;
}


