//
//  AuController.h
//  iOS_Audio
//
//  Created by Fahim Ahmed on 10/17/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioUnit/AudioUnit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "AuMode.h"
#include <vector>
NS_ASSUME_NONNULL_BEGIN

class AuController{
	AudioComponentDescription audioDesc;
	AudioStreamBasicDescription inputAudioFormat, outputAudioFormat;
	AudioComponent inputComponent, outputComponent;
	AudioComponentInstance inputUnit, outputUnit;
	AURenderCallbackStruct inputCallBack, outputCallBack;
    NSMutableArray *bufferQueue;
	AuMode MODE;
    unsigned int bufferIndex;
public:
	AuController();
	AuController(AuMode MODE_PARAMS);
	void AUDIOFW_SET_WAVEINFORMAT(); 	//set the properties of the input unit
	void AUDIOFW_WAVEINOPEN();			//initialize the input unit
	void AUDIOFW_WAVEINSTART();			//start the input unit
	void AUDIOFW_WAVEREAD();			//read the data from the input unit
	void AUDIOFW_WAVEINCLOSE();			//stop the input unit
	void AUDIOFW_WAVEINHANDLE_CLEAR();	//dispose the input unit
	void AUDIOFW_WAVEINHANDLE_CHECK();	//check if dispose was successful
	void AUDIOFW_SET_WAVEOUTFORMAT();	//set the properties of the output unit
	void AUDIOFW_WAVEOUTOPEN();			//initialize the output unit
	void AUDIOFW_WAVEOUTSTART();		//start the output unit
	void AUDIOFW_WAVEWRITE();			//write the data to speaker
	void AUDIOFW_WAVEOUTCLOSE();		//stop the output unit
	void AUDIOFW_WAVEOUTHANDLE_CHECK();
	void AUDIOFW_WAVEHANDLE_CHECK();
	void AUDIOFW_SOUNDDEVICE_GET_REMAINCHUNK(); //get numberOfFrames rendered in the outputBuffer
	void AUDIOFW_ProcessAudio(AudioBufferList &bufferList);
	AudioUnit getInputUnit();
	AudioUnit getOutputUnit();
	NSMutableData* getAudioBuffer(unsigned int index);
    NSMutableData* getNextAudioBuffer();
    bool bufferFinish();
private:
	void AUDIOFW_SET_WAVEDESCRIPTION();
};
NS_ASSUME_NONNULL_END
