//
//  AuMode.h
//  iOS_Audio
//
//  Created by Fahim Ahmed on 10/17/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#ifndef AuMode_h
#define AuMode_h
enum AuMode {
	REALTIME=1, MCPTT=2
};

#endif /* AuMode_h */
