//
//  ViewController.m
//  iOS_Audio
//
//  Created by Fahim Ahmed on 11/5/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//

#import "ViewController.h"
#include "AuController.h"

@interface ViewController ()

@end

@implementation ViewController
{
	AuController *iOS_AudioController;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view from its nib.
}
- (void) initAudio{
	iOS_AudioController = new AuController(MCPTT);
	iOS_AudioController->AUDIOFW_SET_WAVEINFORMAT();
	iOS_AudioController->AUDIOFW_SET_WAVEOUTFORMAT();

	iOS_AudioController->AUDIOFW_WAVEINOPEN();
	iOS_AudioController->AUDIOFW_WAVEOUTOPEN();
}


- (IBAction)RESET_AUDIO_UNIT:(id)sender {
	if(iOS_AudioController->getOutputUnit() != nil){
		iOS_AudioController->AUDIOFW_WAVEINHANDLE_CLEAR();
		iOS_AudioController->AUDIOFW_WAVEOUTHANDLE_CHECK();
	}
	iOS_AudioController = new AuController(MCPTT);

	iOS_AudioController->AUDIOFW_SET_WAVEINFORMAT();
	iOS_AudioController->AUDIOFW_SET_WAVEOUTFORMAT();

	iOS_AudioController->AUDIOFW_WAVEINOPEN();
	iOS_AudioController->AUDIOFW_WAVEOUTOPEN();
}
- (IBAction)WAVE_IN_START:(id)sender {
	iOS_AudioController->AUDIOFW_WAVEINSTART();
}

- (IBAction)WAVE_IN_CLOSE:(id)sender {
	iOS_AudioController->AUDIOFW_WAVEINCLOSE();
	iOS_AudioController->AUDIOFW_WAVEOUTSTART();
}
@end
