//
//  AuController.m
//  iOS_Audio
//
//  Created by Fahim Ahmed on 10/17/18.
//  Copyright © 2018 Fahim Ahmed. All rights reserved.
//



#import "AuController.h"
#include <algorithm>
#include <iostream>

#define BUFFER_LENGTH 1024


#define kOutputBus 0
#define kInputBus 1
OSStatus status;
unsigned int iterationCount;
bool printed;
static OSStatus recordingCallback(void *inRefCon,
								  AudioUnitRenderActionFlags *ioActionFlags,
								  const AudioTimeStamp *inTimeStamp,
								  UInt32 inBusNumber,
								  UInt32 inNumberFrames,
								  AudioBufferList *ioData);

static OSStatus playbackCallback(void *inRefCon,
								 AudioUnitRenderActionFlags *ioActionFlags,
								 const AudioTimeStamp *inTimeStamp,
								 UInt32 inBusNumber,
								 UInt32 inNumberFrames,
								 AudioBufferList *ioData);
void checkStatus(OSStatus var){
	if(var != 0){
		printf("#DEBUG Previous execution Had error\n");
	}
	else{
		printf("#DEBUG Previous execution was successful\n");
	}
}

AuController::AuController(){
	//default constructor
	this->MODE = MCPTT;
	bufferLib = [[NSMutableArray alloc] init];
	this->AUDIOFW_SET_WAVEDESCRIPTION();

}
AuController::AuController(AuMode MODE_PARAMS){
	printf("#DEBUG AuController::AuController()\n");
	//overloaded constructor
	this->MODE = MODE_PARAMS;
	bufferLib = [[NSMutableArray alloc] init];
	this->AUDIOFW_SET_WAVEDESCRIPTION();

}
void AuController::AUDIOFW_SET_WAVEDESCRIPTION(){
	printf("#DEBUG AuController::AUDIOFW_SET_WAVEDESCRIPTION()\n");
	//preparing the audio description
	audioDesc.componentType = kAudioUnitType_Output;
	audioDesc.componentSubType = kAudioUnitSubType_RemoteIO;
	audioDesc.componentFlags = 0;
	audioDesc.componentFlagsMask = 0;
	audioDesc.componentManufacturer = kAudioUnitManufacturer_Apple;
}
void AuController::AUDIOFW_SET_WAVEINFORMAT(){
    printf("#DEBUG AuController::AUDIOFW_SET_WAVEINFORMAT()\n");
    //Specifying the input audio format details
    inputAudioFormat.mSampleRate            = 44100.00;
    inputAudioFormat.mFormatID            = kAudioFormatLinearPCM;
    inputAudioFormat.mFormatFlags        = kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
    inputAudioFormat.mFramesPerPacket    = 1;
    inputAudioFormat.mChannelsPerFrame    = 1;
    inputAudioFormat.mBitsPerChannel        = 16;
    inputAudioFormat.mBytesPerPacket        = 2;
    inputAudioFormat.mBytesPerFrame        = 2;
	
	//initializing the input audio component
	inputComponent = AudioComponentFindNext(NULL, &audioDesc);

	//instantiating an input audioUnit using the component
	status = AudioComponentInstanceNew(inputComponent, &audioInputUnit);
	checkStatus(status);

	unsigned int FLAG = 1;

	//instantiate audio input/recording in seperate audio unit
	status = AudioUnitSetProperty(audioInputUnit,
								  kAudioOutputUnitProperty_EnableIO,
								  kAudioUnitScope_Input,
								  kInputBus,
								  &FLAG,
								  sizeof(FLAG));
	checkStatus(status);

	//setting property for input audio Unit according to format details
	status = AudioUnitSetProperty(audioInputUnit,
								  kAudioUnitProperty_StreamFormat,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &inputAudioFormat,
								  sizeof(inputAudioFormat));
	checkStatus(status);

	//setting input Call Back with required Reference and procedure
	inputCallBack.inputProcRefCon = this;
	inputCallBack.inputProc = recordingCallback;
	status = AudioUnitSetProperty(audioInputUnit,
								  kAudioOutputUnitProperty_SetInputCallback,
								  kAudioUnitScope_Global,
								  kInputBus,
								  &inputCallBack,
								  sizeof(inputCallBack));
	checkStatus(status);

	//Setting mode to manually allocated buffer
	//instead of telling system to allocate buffer
	unsigned int ShouldAllocateBuffer = 0;
	status = AudioUnitSetProperty(audioInputUnit,
								  kAudioUnitProperty_ShouldAllocateBuffer,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &ShouldAllocateBuffer,
								  sizeof(ShouldAllocateBuffer));
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINOPEN(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINOPEN()\n");
	status = AudioUnitInitialize(audioInputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINSTART(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINSTART()\n");
	status = AudioOutputUnitStart(this->audioInputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEREAD(){

}
void AuController::AUDIOFW_WAVEINCLOSE(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINCLOSE()\n");
	status = AudioOutputUnitStop(this->audioInputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEINHANDLE_CLEAR(){
	printf("#DEBUG AuController::AUDIOFW_WAVEINHANDLE_CLEAR()\n");
	AudioComponentInstanceDispose(audioInputUnit);
}
void AuController::AUDIOFW_SET_WAVEOUTFORMAT(){
    printf("#DEBUG AuController::AUDIOFW_SET_WAVEOUTFORMAT()\n");
    //Specifying the output audio format details
    outputAudioFormat.mSampleRate          = 44100.00;
    outputAudioFormat.mFormatID            = kAudioFormatLinearPCM;
    outputAudioFormat.mFormatFlags         = kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
    outputAudioFormat.mFramesPerPacket     = 1;
    outputAudioFormat.mChannelsPerFrame    = 1; //This has to be handled
    outputAudioFormat.mBitsPerChannel      = 16;
    outputAudioFormat.mBytesPerPacket      = 2;
    outputAudioFormat.mBytesPerFrame       = 2;
	
	//initializing the output audio component
	outputComponent = AudioComponentFindNext(NULL, &audioDesc);

	//instantiating an output audioUnit using the component
	status = AudioComponentInstanceNew(outputComponent, &audioOutputUnit);
	checkStatus(status);


	unsigned int FLAG = 1;

	//instantiate audio output/playback in seperate audio unit
	status = AudioUnitSetProperty(audioOutputUnit,
								  kAudioOutputUnitProperty_EnableIO,
								  kAudioUnitScope_Output,
								  kOutputBus,
								  &FLAG,
								  sizeof(FLAG));
	checkStatus(status);


	//setting property for output audio Unit according to format details
	status = AudioUnitSetProperty(audioOutputUnit,
								  kAudioUnitProperty_StreamFormat,
								  kAudioUnitScope_Input,
								  kOutputBus,
								  &outputAudioFormat,
								  sizeof(outputAudioFormat));
	checkStatus(status);


	//setting output Call Back with required Reference and procedure
	outputCallBack.inputProcRefCon = this;
	outputCallBack.inputProc = playbackCallback;
	status = AudioUnitSetProperty(audioOutputUnit,
								  kAudioUnitProperty_SetRenderCallback,
								  kAudioUnitScope_Global,
								  kOutputBus,
								  &outputCallBack,
								  sizeof(outputCallBack));
	checkStatus(status);


	//Setting mode to manually allocated buffer
	//instead of telling system to allocate buffer
	unsigned int ShouldAllocateBuffer = 0;
	status = AudioUnitSetProperty(audioOutputUnit,
								  kAudioUnitProperty_ShouldAllocateBuffer,
								  kAudioUnitScope_Output,
								  kInputBus,
								  &ShouldAllocateBuffer,
								  sizeof(ShouldAllocateBuffer));
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEOUTOPEN(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTOPEN()\n");
	status = AudioUnitInitialize(audioOutputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEOUTSTART(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTSTART()\n");
	iterationCount = 0;
	printed = false;
	status = AudioOutputUnitStart(this->audioOutputUnit);
	checkStatus(status);

}
void AuController::AUDIOFW_WAVEOUTCLOSE(){
	printf("#DEBUG AuController::AUDIOFW_WAVEOUTCLOSE()\n");
	status = AudioOutputUnitStop(this->audioOutputUnit);
	checkStatus(status);
}
void AuController::AUDIOFW_WAVEOUTHANDLE_CHECK(){
	status = AudioComponentInstanceDispose(this->audioOutputUnit);
	checkStatus(status);
}
AudioUnit AuController::getInputUnit(){
	return this->audioInputUnit;
}
AudioUnit AuController::getOutputUnit(){
	return this->audioOutputUnit;
}
//AudioBuffer AuController::getAudioBuffer(){
//	return this->audioBuffer;
//}

void AuController::AUDIOFW_ProcessAudio(AudioBufferList &bufferList){
	printf("#DEBUG AuController::AUDIOFW_ProcessAudio()\n");
	AudioBuffer sourceBuffer = bufferList.mBuffers[0];
	Float32 *frame = (Float32*) sourceBuffer.mData;
	NSMutableData *data = [[NSMutableData alloc] init];
	[data appendBytes:frame length:sourceBuffer.mDataByteSize];
	[bufferLib addObject:data];

//	if(!printed)printf("\n\n#DEBUG DATA\n");
//	for(int i=0; i < std::min((unsigned long)5, [bufferLib count]) && !printed; i++){
//		NSLog(@"#DEBUG DATA No. %d = %@\n\n",i, bufferLib[i]);
//		if(i == 4){
//			printed=1;
//		}
//	}
}

static OSStatus recordingCallback(void *inRefCon,
								  AudioUnitRenderActionFlags *ioActionFlags,
								  const AudioTimeStamp *inTimeStamp,
								  UInt32 inBusNumber,
								  UInt32 inNumberFrames,
								  AudioBufferList *ioData) {
	AudioBuffer buffer;
	buffer.mNumberChannels = 1;
	buffer.mDataByteSize = inNumberFrames * 2;
	buffer.mData = malloc(inNumberFrames * 2);

	AudioBufferList bufferList;
	bufferList.mNumberBuffers = 1;
	bufferList.mBuffers[0] = buffer;

	AuController &controllerInstance = *(AuController*)inRefCon;

	status = AudioUnitRender(controllerInstance.getInputUnit(),
							 ioActionFlags,
							 inTimeStamp,
							 inBusNumber,
							 inNumberFrames,
							 &bufferList);
	checkStatus(status);


	controllerInstance.AUDIOFW_ProcessAudio(bufferList);
	free(bufferList.mBuffers[0].mData);

	return noErr;
}
static OSStatus playbackCallback(void *inRefCon,
								 AudioUnitRenderActionFlags *ioActionFlags,
								 const AudioTimeStamp *inTimeStamp,
								 UInt32 inBusNumber,
								 UInt32 inNumberFrames,
								 AudioBufferList *ioData) {
	AuController &controllerInstance = *(AuController*)inRefCon;
	//printf("#DEBUG in PLAYBACK Size = %lu\n", [controllerInstance.bufferLib count]);
	if(iterationCount == [controllerInstance.bufferLib count]){
		controllerInstance.AUDIOFW_WAVEOUTCLOSE();
	}
//	if(iterationCount < 1){
//		NSLog(@"DATA PLAYBACK = %@",[NSData dataWithBytes:controllerInstance.bufferQueue[iterationCount].mData length:controllerInstance.bufferQueue[iterationCount].mDataByteSize]);
//	}
	AudioBuffer buffer = ioData->mBuffers[0];
	unsigned int size = std::min((unsigned int)buffer.mDataByteSize, (unsigned int)[controllerInstance.bufferLib[iterationCount] length]);
	const void *_Nullable audioFrame = [controllerInstance.bufferLib[iterationCount] bytes];
	memcpy(buffer.mData, audioFrame, size);
	buffer.mDataByteSize = size;
	iterationCount++;
	return noErr;
}


