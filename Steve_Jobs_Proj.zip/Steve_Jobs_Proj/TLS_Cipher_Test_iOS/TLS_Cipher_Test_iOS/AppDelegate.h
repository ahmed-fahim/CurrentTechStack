//
//  AppDelegate.h
//  TLS_Cipher_Test_iOS
//
//  Created by Fahim Ahmed on 7/2/19.
//  Copyright © 2019 com.samsung.srbd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController/PrimaryViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) PrimaryViewController *initialVC;
@property (strong, nonatomic) UINavigationController *rootVC;
@property (strong, nonatomic) UIWindow *window;

@end

