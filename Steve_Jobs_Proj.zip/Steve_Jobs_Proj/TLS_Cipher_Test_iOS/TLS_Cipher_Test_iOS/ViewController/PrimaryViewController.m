//
//  PrimaryViewController.m
//  TLS_Cipher_Test_iOS
//
//  Created by Fahim Ahmed on 7/2/19.
//  Copyright © 2019 com.samsung.srbd. All rights reserved.
//

#import "PrimaryViewController.h"

@interface PrimaryViewController ()

@end

@implementation PrimaryViewController

- (void) viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

///implementation of protocol method under protocol NSURLSessionDelegate
- (void) URLSession:(NSURLSession *)session
didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
  completionHandler:( void (^ _Nonnull )(NSURLSessionAuthChallengeDisposition, NSURLCredential * _Nullable))completionHandler{
	if(challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust){
		SecTrustRef __nonnull serverTrust = challenge.protectionSpace.serverTrust;
		if(serverTrust != nil){
			SecTrustResultType secresult = kSecTrustResultInvalid;
			OSStatus status = SecTrustEvaluate(serverTrust, &secresult);
			if(status == errSecSuccess){
				SecCertificateRef __nonnull serverCertificate = SecTrustGetCertificateAtIndex(serverTrust, 0);
				if(serverCertificate != nil){
					completionHandler(NSURLSessionAuthChallengeUseCredential, [NSURLCredential credentialForTrust:serverTrust]);
					return;
				}
			}
		}
	}
	completionHandler(NSURLSessionAuthChallengeCancelAuthenticationChallenge, nil);
}

- (void) doHttpsFetch_urlString:(NSString*) urlString{
	NSMutableURLRequest *urlRequest;
	NSURL *url = [NSURL URLWithString:urlString];
	urlRequest = [NSMutableURLRequest requestWithURL:url];

	NSURLSessionConfiguration *defaultConfigObject =  [NSURLSessionConfiguration defaultSessionConfiguration];
	NSURLSession *TLS_Session = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];

	NSURLSessionDataTask *dataTask = [TLS_Session dataTaskWithRequest:urlRequest
													completionHandler:
									  ^(NSData *data, NSURLResponse *response, NSError *error){
										  if(error == nil){
											  NSString* receivedData = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
											  [self showDataInConsole_text:receivedData];

										  }
										  else{
											  [self showDataInConsole_text:[NSString stringWithFormat:@"Error %ld occured", (long)[error code]]];
										  }
									  } ];
	[dataTask resume];
}



- (IBAction)connectGoogle:(id)sender {
	[self doHttpsFetch_urlString:@"https://developer.apple.com"];
}

- (IBAction)connectDeveloperApple:(id)sender {
	[self doHttpsFetch_urlString:@"https://developer.apple.com"];
}

- (void) showDataInConsole_text:(NSString*)text{
	dispatch_async(dispatch_get_main_queue(),
				   ^{
//					   self.textConsole.text = [self.textConsole.text stringByAppendingFormat:@"%@\n", text];
					   self.textConsole.text = text;
				   });
}
@end
