//
//  PrimaryViewController.h
//  TLS_Cipher_Test_iOS
//
//  Created by Fahim Ahmed on 7/2/19.
//  Copyright © 2019 com.samsung.srbd. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PrimaryViewController : UIViewController <NSURLSessionDelegate>
- (IBAction)connectGoogle:(id)sender;
- (IBAction)connectDeveloperApple:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *textConsole;

@end

NS_ASSUME_NONNULL_END
