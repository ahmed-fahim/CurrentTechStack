//
//  HomeViewController.swift
//  SwiftDemoUI
//
//  Created by Fahim Ahmed on 2/13/19.
//  Copyright © 2019 com.samsung.srbd.push.test. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
	@IBOutlet weak var ChannelContainer: UIView!
	@IBOutlet weak var ContactContainer: UIView!
	@IBOutlet weak var tabPager: UISegmentedControl!
	var channelListVC: ChannelListViewController!
	
	override func viewDidLoad() {
        super.viewDidLoad()
		
        // Do any additional setup after loading the view.
		channelListVC = ChannelListViewController.init(nibName: "ChannelListViewController", bundle: nil)
		self.addChild(channelListVC)
		ChannelContainer.addSubview(channelListVC.view)
		channelListVC.didMove(toParent: self)
    }
	override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
		super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
	}
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
